"""SQL Query Analysis Agent"""

__version__ = "0.1.0"
__author__ = "Vineel-007"

from agent.analyzer import SQLAnalyzer

__all__ = ["SQLAnalyzer"]