"""Base LLM class"""

from abc import ABC, abstractmethod
from typing import Optional


class BaseLLM(ABC):
    """Base class for LLM integrations"""

    def __init__(self, model: str, temperature: float = 0.7, max_tokens: int = 2000):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    @abstractmethod
    def query(self, prompt: str) -> str:
        """Send query to LLM"""
        pass

    @abstractmethod
    def analyze_query(self, sql_query: str) -> str:
        """Analyze SQL query"""
        pass