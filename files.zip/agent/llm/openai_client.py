"""OpenAI LLM client"""

import logging
from typing import Optional
from agent.llm.base import BaseLLM

logger = logging.getLogger(__name__)


class OpenAIClient(BaseLLM):
    """OpenAI LLM client"""

    def __init__(self, api_key: str, model: str = "gpt-4", temperature: float = 0.7, max_tokens: int = 2000):
        super().__init__(model, temperature, max_tokens)
        self.api_key = api_key
        self.client = None

        try:
            import openai
            openai.api_key = api_key
            self.client = openai.ChatCompletion
        except ImportError:
            logger.warning("OpenAI library not installed")

    def query(self, prompt: str) -> str:
        """Send query to OpenAI"""
        if not self.client:
            return "OpenAI client not initialized"

        try:
            response = self.client.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI query failed: {str(e)}")
            return f"Error: {str(e)}"

    def analyze_query(self, sql_query: str) -> str:
        """Analyze SQL query using OpenAI"""
        prompt = f"""Analyze this SQL query and provide insights:

Query:
{sql_query}

Please provide:
1. What this query does
2. Performance considerations
3. Security issues if any
4. Optimization suggestions"""

        return self.query(prompt)