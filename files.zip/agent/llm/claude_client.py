"""Claude LLM client"""

import logging
from agent.llm.base import BaseLLM

logger = logging.getLogger(__name__)


class ClaudeClient(BaseLLM):
    """Claude LLM client"""

    def __init__(self, api_key: str, model: str = "claude-2", temperature: float = 0.7, max_tokens: int = 2000):
        super().__init__(model, temperature, max_tokens)
        self.api_key = api_key
        self.client = None

        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=api_key)
        except ImportError:
            logger.warning("Anthropic library not installed")

    def query(self, prompt: str) -> str:
        """Send query to Claude"""
        if not self.client:
            return "Claude client not initialized"

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"Claude query failed: {str(e)}")
            return f"Error: {str(e)}"

    def analyze_query(self, sql_query: str) -> str:
        """Analyze SQL query using Claude"""
        prompt = f"""Analyze this SQL query and provide insights:

Query:
{sql_query}

Please provide:
1. What this query does
2. Performance considerations
3. Security issues if any
4. Optimization suggestions"""

        return self.query(prompt)