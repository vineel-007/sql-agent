"""Query explanation module"""

import logging
import re
from typing import Dict, List

logger = logging.getLogger(__name__)


class ExplanationGenerator:
    """Generates human-readable explanations of SQL queries"""

    def explain(self, query: str) -> str:
        """Generate explanation for SQL query"""
        query_type = self._get_query_type(query)
        explanation = f"This is a {query_type} query that:\n\n"

        if "SELECT" in query.upper():
            explanation += self._explain_select(query)
        elif "INSERT" in query.upper():
            explanation += self._explain_insert(query)
        elif "UPDATE" in query.upper():
            explanation += self._explain_update(query)
        elif "DELETE" in query.upper():
            explanation += self._explain_delete(query)

        return explanation

    def _get_query_type(self, query: str) -> str:
        """Determine query type"""
        query_upper = query.upper()
        if "SELECT" in query_upper:
            return "SELECT"
        elif "INSERT" in query_upper:
            return "INSERT"
        elif "UPDATE" in query_upper:
            return "UPDATE"
        elif "DELETE" in query_upper:
            return "DELETE"
        else:
            return "Unknown"

    def _explain_select(self, query: str) -> str:
        """Explain SELECT query"""
        explanation = ""

        # Extract columns
        columns_match = re.search(r"SELECT\s+(.+?)\s+FROM", query, re.IGNORECASE)
        if columns_match:
            columns = columns_match.group(1)
            explanation += f"1. Selects: {columns}\n"

        # Extract table
        table_match = re.search(r"FROM\s+([^\s,]+)", query, re.IGNORECASE)
        if table_match:
            table = table_match.group(1)
            explanation += f"2. From table: {table}\n"

        # Extract WHERE conditions
        where_match = re.search(r"WHERE\s+(.+?)(?:GROUP|ORDER|LIMIT|$)", query, re.IGNORECASE)
        if where_match:
            conditions = where_match.group(1)
            explanation += f"3. With conditions: {conditions}\n"

        # Extract JOINs
        joins = re.findall(r"(JOIN\s+\S+\s+ON\s+[^A-Z]+)", query, re.IGNORECASE)
        if joins:
            for join in joins:
                explanation += f"4. Join: {join}\n"

        return explanation

    def _explain_insert(self, query: str) -> str:
        """Explain INSERT query"""
        explanation = ""

        table_match = re.search(r"INTO\s+(\S+)", query, re.IGNORECASE)
        if table_match:
            table = table_match.group(1)
            explanation += f"1. Inserts into table: {table}\n"

        columns_match = re.search(r"INTO\s+\S+\s*\((.+?)\)", query, re.IGNORECASE)
        if columns_match:
            columns = columns_match.group(1)
            explanation += f"2. Columns: {columns}\n"

        return explanation

    def _explain_update(self, query: str) -> str:
        """Explain UPDATE query"""
        explanation = ""

        table_match = re.search(r"UPDATE\s+(\S+)", query, re.IGNORECASE)
        if table_match:
            table = table_match.group(1)
            explanation += f"1. Updates table: {table}\n"

        set_match = re.search(r"SET\s+(.+?)(?:WHERE|$)", query, re.IGNORECASE)
        if set_match:
            sets = set_match.group(1)
            explanation += f"2. Sets: {sets}\n"

        return explanation

    def _explain_delete(self, query: str) -> str:
        """Explain DELETE query"""
        explanation = ""

        table_match = re.search(r"FROM\s+(\S+)", query, re.IGNORECASE)
        if table_match:
            table = table_match.group(1)
            explanation += f"1. Deletes from table: {table}\n"

        where_match = re.search(r"WHERE\s+(.+?)$", query, re.IGNORECASE)
        if where_match:
            conditions = where_match.group(1)
            explanation += f"2. Where: {conditions}\n"

        return explanation