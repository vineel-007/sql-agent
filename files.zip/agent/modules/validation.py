"""SQL Query Validation Module"""

import logging
from typing import List, Dict, Any
import sqlparse

logger = logging.getLogger(__name__)


class ValidationError:
    """Represents a validation error"""

    def __init__(self, error_type: str, message: str, line: int = 0, position: int = 0):
        self.type = error_type
        self.message = message
        self.line = line
        self.position = position

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "message": self.message,
            "line": self.line,
            "position": self.position,
        }


class ValidationResult:
    """Validation result object"""

    def __init__(self, valid: bool, errors: List[ValidationError] = None):
        self.valid = valid
        self.errors = errors or []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "error_count": len(self.errors),
            "errors": [e.to_dict() for e in self.errors],
        }


class SQLValidator:
    """Validates SQL queries"""

    def validate(self, query: str) -> ValidationResult:
        """Validate SQL query"""
        errors = []

        if not query or not query.strip():
            errors.append(ValidationError("EMPTY_QUERY", "Query is empty"))
            return ValidationResult(False, errors)

        try:
            parsed = sqlparse.parse(query)
            if not parsed:
                errors.append(ValidationError("PARSE_ERROR", "Failed to parse query"))
            else:
                for statement in parsed:
                    if statement.get_type() is None:
                        errors.append(
                            ValidationError("UNKNOWN_STATEMENT", "Unable to determine statement type")
                        )
        except Exception as e:
            errors.append(
                ValidationError("PARSE_ERROR", f"Failed to parse query: {str(e)}")
            )

        syntax_errors = self._check_syntax(query)
        errors.extend(syntax_errors)

        return ValidationResult(len(errors) == 0, errors)

    def _check_syntax(self, query: str) -> List[ValidationError]:
        """Check for common syntax issues"""
        errors = []

        open_parens = query.count("(")
        close_parens = query.count(")")
        if open_parens != close_parens:
            errors.append(
                ValidationError(
                    "UNMATCHED_PARENS",
                    f"Unmatched parentheses: {open_parens} open, {close_parens} close",
                )
            )

        single_quotes = query.count("'") - query.count("\\'")
        double_quotes = query.count('"') - query.count('\\"')
        if single_quotes % 2 != 0:
            errors.append(
                ValidationError("UNMATCHED_QUOTES", "Unmatched single quotes")
            )
        if double_quotes % 2 != 0:
            errors.append(
                ValidationError("UNMATCHED_QUOTES", "Unmatched double quotes")
            )

        return errors