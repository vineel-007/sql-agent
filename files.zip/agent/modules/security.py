"""Security vulnerability detection module"""

import logging
import re
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class SecurityIssue:
    """Represents a security issue"""

    def __init__(self, severity: str, issue_type: str, message: str, pattern: str = ""):
        self.severity = severity  # HIGH, MEDIUM, LOW
        self.type = issue_type
        self.message = message
        self.pattern = pattern

    def to_dict(self) -> Dict[str, Any]:
        return {
            "severity": self.severity,
            "type": self.type,
            "message": self.message,
            "pattern": self.pattern,
        }


class SecurityAnalyzer:
    """Analyzes SQL queries for security vulnerabilities"""

    INJECTION_PATTERNS = [
        (r"(UNION\s+SELECT|UNION\s+ALL)", "SQL Injection via UNION"),
        (r"(OR\s+'[^']*'\s*=\s*'[^']*'|OR\s+1\s*=\s*1)", "SQL Injection via OR condition"),
        (r"(';.*--|--.*\n)", "SQL Injection via comment"),
        (r"(DROP\s+TABLE|DELETE\s+FROM|UPDATE\s+[^ ]+\s+SET)", "Dangerous operations"),
        (r"(xp_|sp_exec|exec\s*\()", "Extended stored procedures"),
    ]

    def analyze(self, query: str) -> List[SecurityIssue]:
        """Analyze query for security vulnerabilities"""
        issues = []

        issues.extend(self._check_injection_patterns(query))
        issues.extend(self._check_parameterization(query))
        issues.extend(self._check_privileges(query))

        return issues

    def _check_injection_patterns(self, query: str) -> List[SecurityIssue]:
        """Check for SQL injection patterns"""
        issues = []
        query_upper = query.upper()

        for pattern, description in self.INJECTION_PATTERNS:
            if re.search(pattern, query_upper, re.IGNORECASE):
                severity = "HIGH" if "INJECTION" in description else "MEDIUM"
                issues.append(
                    SecurityIssue(
                        severity=severity,
                        issue_type="SQL_INJECTION",
                        message=f"Potential {description}",
                        pattern=pattern,
                    )
                )

        return issues

    def _check_parameterization(self, query: str) -> List[SecurityIssue]:
        """Check if query uses parameterized queries"""
        issues = []

        # Check for string concatenation patterns
        if re.search(r"'\s*\+\s*['\"]", query, re.IGNORECASE):
            issues.append(
                SecurityIssue(
                    severity="HIGH",
                    issue_type="PARAMETERIZATION",
                    message="Query uses string concatenation instead of parameterized queries",
                )
            )

        return issues

    def _check_privileges(self, query: str) -> List[SecurityIssue]:
        """Check for privilege escalation risks"""
        issues = []
        query_upper = query.upper()

        if query_upper.count("DROP") > 0 or query_upper.count("DELETE") > 0:
            issues.append(
                SecurityIssue(
                    severity="HIGH",
                    issue_type="PRIVILEGE",
                    message="Query performs destructive operations",
                )
            )

        return issues

    def get_recommendations(self, issues: List[SecurityIssue]) -> List[str]:
        """Get security recommendations"""
        recommendations = []

        for issue in issues:
            if issue.type == "SQL_INJECTION":
                recommendations.append("Use parameterized queries or prepared statements")
            elif issue.type == "PARAMETERIZATION":
                recommendations.append("Replace string concatenation with parameter placeholders")
            elif issue.type == "PRIVILEGE":
                recommendations.append("Ensure proper authorization checks before executing destructive operations")

        return recommendations