"""Database connection handler"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DatabaseConnector:
    """Handles database connections"""

    def __init__(
        self,
        db_type: str,
        host: str,
        port: int,
        database: str,
        user: str,
        password: str,
    ):
        self.db_type = db_type
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None

    def connect(self) -> bool:
        """Connect to database"""
        try:
            if self.db_type == "postgresql":
                import psycopg2

                self.connection = psycopg2.connect(
                    host=self.host,
                    port=self.port,
                    database=self.database,
                    user=self.user,
                    password=self.password,
                )
            elif self.db_type == "mysql":
                import mysql.connector

                self.connection = mysql.connector.connect(
                    host=self.host,
                    port=self.port,
                    database=self.database,
                    user=self.user,
                    password=self.password,
                )
            else:
                logger.error(f"Unsupported database type: {self.db_type}")
                return False

            logger.info(f"Connected to {self.db_type} database")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to database: {str(e)}")
            return False

    def execute(self, query: str) -> Optional[List[Dict[str, Any]]]:
        """Execute query on database"""
        try:
            if not self.connection:
                logger.error("No database connection")
                return None

            cursor = self.connection.cursor()
            cursor.execute(query)

            if query.strip().upper().startswith("SELECT"):
                columns = [desc[0] for desc in cursor.description]
                results = []
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                return results
            else:
                self.connection.commit()
                return {"rows_affected": cursor.rowcount}

        except Exception as e:
            logger.error(f"Failed to execute query: {str(e)}")
            return None
        finally:
            if cursor:
                cursor.close()

    def disconnect(self):
        """Disconnect from database"""
        if self.connection:
            self.connection.close()
            logger.info("Disconnected from database")

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()