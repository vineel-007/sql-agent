"""Tests for performance module"""

import pytest
from agent.modules import PerformanceAnalyzer


@pytest.mark.unit
def test_select_all_detection(performance_analyzer):
    """Test SELECT * detection"""
    query = "SELECT * FROM users"
    issues = performance_analyzer.analyze(query)
    assert any(i.type == "SELECT_ALL" for i in issues)


@pytest.mark.unit
def test_complex_joins(performance_analyzer):
    """Test complex join detection"""
    query = """
    SELECT * FROM a
    JOIN b ON a.id = b.a_id
    JOIN c ON b.id = c.b_id
    JOIN d ON c.id = d.c_id
    JOIN e ON d.id = e.d_id
    """
    issues = performance_analyzer.analyze(query)
    assert isinstance(issues, list)