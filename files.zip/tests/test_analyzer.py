"""Tests for main analyzer"""

import pytest
from agent.analyzer import SQLAnalyzer


@pytest.mark.unit
def test_analyzer_init():
    """Test analyzer initialization"""
    analyzer = SQLAnalyzer(llm_provider="openai")
    assert analyzer is not None
    assert analyzer.validator is not None


@pytest.mark.unit
def test_analyze_simple_query():
    """Test analyze simple query"""
    analyzer = SQLAnalyzer(llm_provider="openai")
    query = "SELECT id, name FROM users WHERE id = 1"
    result = analyzer.analyze(query)
    assert result is not None
    assert hasattr(result, 'valid')