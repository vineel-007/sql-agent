"""Tests for security module"""

import pytest
from agent.modules import SecurityAnalyzer


@pytest.mark.unit
def test_sql_injection_union(security_analyzer):
    """Test UNION injection detection"""
    query = "SELECT * FROM users WHERE id = 1 UNION SELECT * FROM admin"
    issues = security_analyzer.analyze(query)
    assert len(issues) > 0


@pytest.mark.unit
def test_sql_injection_or(security_analyzer):
    """Test OR injection detection"""
    query = "SELECT * FROM users WHERE id = '1' OR '1'='1'"
    issues = security_analyzer.analyze(query)
    assert len(issues) > 0


@pytest.mark.unit
def test_parameterization_warning(security_analyzer):
    """Test string concatenation warning"""
    query = "SELECT * FROM users WHERE id = '" + "1" + "'"
    issues = security_analyzer.analyze(query)
    # Should find some issues or pass
    assert isinstance(issues, list)