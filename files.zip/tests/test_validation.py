"""Tests for validation module"""

import pytest
from agent.modules import SQLValidator


@pytest.mark.unit
def test_empty_query(validator):
    """Test empty query validation"""
    result = validator.validate("")
    assert not result.valid
    assert len(result.errors) > 0


@pytest.mark.unit
def test_valid_select(validator):
    """Test valid SELECT query"""
    query = "SELECT id, name FROM users"
    result = validator.validate(query)
    assert result.valid or len(result.errors) == 0


@pytest.mark.unit
def test_unmatched_parentheses(validator):
    """Test unmatched parentheses"""
    query = "SELECT * FROM users WHERE id IN (1, 2, 3"
    result = validator.validate(query)
    assert not result.valid


@pytest.mark.unit
def test_unmatched_quotes(validator):
    """Test unmatched quotes"""
    query = "SELECT * FROM users WHERE name = 'John"
    result = validator.validate(query)
    assert not result.valid