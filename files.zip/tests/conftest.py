"""Pytest configuration"""

import pytest
from agent.modules import SQLValidator, SecurityAnalyzer, PerformanceAnalyzer


@pytest.fixture
def validator():
    """Validator fixture"""
    return SQLValidator()


@pytest.fixture
def security_analyzer():
    """Security analyzer fixture"""
    return SecurityAnalyzer()


@pytest.fixture
def performance_analyzer():
    """Performance analyzer fixture"""
    return PerformanceAnalyzer()