from setuptools import setup, find_packages

setup(
    name="sql-agent",
    version="0.1.0",
    description="SQL Query Analysis Agent with LLM Integration",
    author="Vineel-007",
    url="https://github.com/vineel-007/sql-agent",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "sqlparse>=0.4.4",
        "python-dotenv>=1.0.0",
        "openai>=1.3.0",
        "anthropic>=0.7.0",
        "psycopg2-binary>=2.9.9",
        "pydantic>=2.4.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "black>=23.10.0",
            "pylint>=3.0.0",
            "flake8>=6.1.0",
        ]
    },
)